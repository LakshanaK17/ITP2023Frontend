import React from "react";

const Employee = () => {
  return (
    <div>
      <h2>Welcome to the Employee Page!</h2>
      <p>You are logged in as a employee.</p>
    </div>
  );
};

export default Employee;
