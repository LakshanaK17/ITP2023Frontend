import React from "react";

const UserPage = () => {
  return (
    <div>
      <h2>Welcome to the User Page!</h2>
      <p>You are logged in as a user.</p>
    </div>
  );
};

export default UserPage;
