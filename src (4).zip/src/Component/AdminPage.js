import React from "react";

const AdminPage = () => {
  return (
    <div>
      <h2>Welcome to the Admin Page!</h2>
      <p>You are logged in as an admin.</p>
    </div>
  );
};

export default AdminPage;
